import java.util.*;
import java.lang.*;
interface bank
{
    void withdrawing(int amount);
    void depositing(int amount);
    void balance();
}
class account implements bank {
    
    static int ba, ch;

        public void withdrawing( int amount)
        {
            ba = ba - amount;
            System.out.println(ba);
        }
        public void depositing ( int amount)
        {
            ba = ba + amount;
            System.out.println(ba);
        }
        public void balance ()
        {
            System.out.println(ba);
        }

    public static void main(String args[]) {

        Scanner sc = new Scanner(System.in);
        System.out.println("enter balance");
        ba = sc.nextInt();
        System.out.println("enter choice : \n1.Withdraw \n2.Deposit \n3.Balance");
        ch = sc.nextInt();
        account a = new account();
        switch (ch) {
            case 1:
                System.out.println("enter withdrawing money");
                int withdraw = sc.nextInt();
                if (withdraw > ba)
                    System.out.println("insufficient balance");
                a.withdrawing(withdraw);
                break;
            case 2:
                System.out.println("enter depositing money");
                int deposite = sc.nextInt();
                a.depositing(deposite);
                break;
            case 3:
                a.balance();
                break;
            case 4:
                System.exit(0);
        }
    }

}
